package com.proj.offlinepost;
/*

// 1st phone upload


import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private static final int PERMISSIONS_REQUEST_READ_CONTACTS = 100;
    private TextView contactInfoTextView;
    private Button importButton, syncButton;
    private JSONArray contactsArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        contactInfoTextView = findViewById(R.id.contact_info);
        importButton = findViewById(R.id.btn_import);
        syncButton = findViewById(R.id.btn_sync);

        importButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_CONTACTS}, PERMISSIONS_REQUEST_READ_CONTACTS);
                } else {
                    importContacts();
                }
            }
        });

        syncButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new SyncDataTask().execute();
            }
        });
    }

    @SuppressLint("Range")
    private void importContacts() {
        contactsArray = new JSONArray();
        ContentResolver contentResolver = getContentResolver();
        Cursor cursor = contentResolver.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);

        if (cursor != null && cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                @SuppressLint("Range") String id = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));
                @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));

                if (cursor.getInt(cursor.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER)) > 0) {
                    Cursor pCursor = contentResolver.query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                            new String[]{id}, null);

                    while (pCursor != null && pCursor.moveToNext()) {
                        String phoneNumber = pCursor.getString(pCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                        JSONObject contact = new JSONObject();
                        try {
                            contact.put("name", name);
                            contact.put("phone", phoneNumber);
                            contactsArray.put(contact);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    if (pCursor != null) {
                        pCursor.close();
                    }
                }
            }
            cursor.close();
            contactInfoTextView.setText(contactsArray.toString());
            saveContactsOffline();
        }
    }

    private void saveContactsOffline() {
        try {
            Writer output = null;
            String fileName = "contacts.json";
            output = new BufferedWriter(new OutputStreamWriter(openFileOutput(fileName, Context.MODE_PRIVATE)));
            output.write(contactsArray.toString());
            output.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private class SyncDataTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... voids) {
            String fileName = "contacts.json";
            String result = null;

            try {
                InputStream inputStream = openFileInput(fileName);
                if (inputStream != null) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                    StringBuilder stringBuilder = new StringBuilder();
                    String receiveString;
                    while ((receiveString = bufferedReader.readLine()) != null) {
                        stringBuilder.append(receiveString);
                    }
                    inputStream.close();
                    String contactsJson = stringBuilder.toString();
                    result = syncContacts(contactsJson);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            Toast.makeText(MainActivity.this, result, Toast.LENGTH_LONG).show();
        }

        private String syncContacts(String contactsJson) {
            String result = "";
            try {
                URL url = new URL("http://192.168.40.93/testing/offlinedata/sync_contacts.php");
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);

                Writer writer = new BufferedWriter(new OutputStreamWriter(httpURLConnection.getOutputStream(), "UTF-8"));
                writer.write(contactsJson);
                writer.close();

                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line);
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                result = stringBuilder.toString();
            } catch (MalformedURLException e) {
                e.printStackTrace();
                result = "MalformedURLException: " + e.getMessage();
            } catch (IOException e) {
                e.printStackTrace();
                result = "IOException: " + e.getMessage();
            }
            return result;
        }
    }
}*/

/*

// 2nd text input
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private EditText editTextName, editTextPhone;
    private TextView contactInfoTextView;
    private Button saveButton, syncButton;
    private JSONArray contactsArray;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextName = findViewById(R.id.editTextName);
        editTextPhone = findViewById(R.id.editTextPhone);
        contactInfoTextView = findViewById(R.id.contact_info);
        saveButton = findViewById(R.id.btn_save);
        syncButton = findViewById(R.id.btn_sync);

        contactsArray = new JSONArray();

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveContact();
            }
        });

        syncButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new SyncDataTask().execute();
            }
        });
    }

    private void saveContact() {
        String name = editTextName.getText().toString();
        String phone = editTextPhone.getText().toString();

        if (!name.isEmpty() && !phone.isEmpty()) {
            JSONObject contact = new JSONObject();
            try {
                contact.put("name", name);
                contact.put("phone", phone);
                contactsArray.put(contact);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            contactInfoTextView.setText(contactsArray.toString());
            saveContactsOffline();
        } else {
            Toast.makeText(this, "Please enter both name and phone number", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveContactsOffline() {
        try {
            Writer output = null;
            String fileName = "contacts.json";
            output = new BufferedWriter(new OutputStreamWriter(openFileOutput(fileName, Context.MODE_PRIVATE)));
            output.write(contactsArray.toString());
            output.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private class SyncDataTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... voids) {
            String fileName = "contacts.json";
            String result = null;

            try {
                InputStream inputStream = openFileInput(fileName);
                if (inputStream != null) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                    StringBuilder stringBuilder = new StringBuilder();
                    String receiveString;
                    while ((receiveString = bufferedReader.readLine()) != null) {
                        stringBuilder.append(receiveString);
                    }
                    inputStream.close();
                    String contactsJson = stringBuilder.toString();
                    result = syncContacts(contactsJson);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            Toast.makeText(MainActivity.this, result, Toast.LENGTH_LONG).show();
        }

        private String syncContacts(String contactsJson) {
            String result = "";
            try {
                URL url = new URL("http://192.168.40.93/testing/offlinedata/sync_contacts.php");
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);

                Writer writer = new BufferedWriter(new OutputStreamWriter(httpURLConnection.getOutputStream(), "UTF-8"));
                writer.write(contactsJson);
                writer.close();

                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line);
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                result = stringBuilder.toString();
            } catch (MalformedURLException e) {
                e.printStackTrace();
                result = "MalformedURLException: " + e.getMessage();
            } catch (IOException e) {
                e.printStackTrace();
                result = "IOException: " + e.getMessage();
            }
            return result;
        }
    }
}
*/

// 3rd local save

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private EditText editTextName, editTextPhone;
    private TextView contactInfoTextView;
    private Button saveButton, syncButton;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextName = findViewById(R.id.editTextName);
        editTextPhone = findViewById(R.id.editTextPhone);
        contactInfoTextView = findViewById(R.id.contact_info);
        saveButton = findViewById(R.id.btn_save);
        syncButton = findViewById(R.id.btn_sync);

        dbHelper = new DatabaseHelper(this);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveContact();
            }
        });

        syncButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new SyncDataTask().execute();
            }
        });

        loadContactsFromDatabase();
    }

    private void saveContact() {
        String name = editTextName.getText().toString();
        String phone = editTextPhone.getText().toString();

        if (!name.isEmpty() && !phone.isEmpty()) {
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(DatabaseHelper.COLUMN_NAME, name);
            values.put(DatabaseHelper.COLUMN_PHONE, phone);

            long newRowId = db.insert(DatabaseHelper.TABLE_CONTACTS, null, values);

            if (newRowId != -1) {
                Toast.makeText(this, "Contact saved", Toast.LENGTH_SHORT).show();
                loadContactsFromDatabase();
            } else {
                Toast.makeText(this, "Error saving contact", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please enter both name and phone number", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadContactsFromDatabase() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {
                DatabaseHelper.COLUMN_ID,
                DatabaseHelper.COLUMN_NAME,
                DatabaseHelper.COLUMN_PHONE
        };

        Cursor cursor = db.query(
                DatabaseHelper.TABLE_CONTACTS,
                projection,
                null,
                null,
                null,
                null,
                null
        );

        JSONArray contactsArray = new JSONArray();
        while (cursor.moveToNext()) {
            String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NAME));
            String phone = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_PHONE));

            JSONObject contact = new JSONObject();
            try {
                contact.put("name", name);
                contact.put("phone", phone);
                contactsArray.put(contact);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        cursor.close();

        contactInfoTextView.setText(contactsArray.toString());
    }

    private class SyncDataTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... voids) {
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            String[] projection = {
                    DatabaseHelper.COLUMN_NAME,
                    DatabaseHelper.COLUMN_PHONE
            };

            Cursor cursor = db.query(
                    DatabaseHelper.TABLE_CONTACTS,
                    projection,
                    null,
                    null,
                    null,
                    null,
                    null
            );

            JSONArray contactsArray = new JSONArray();
            while (cursor.moveToNext()) {
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NAME));
                String phone = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_PHONE));

                JSONObject contact = new JSONObject();
                try {
                    contact.put("name", name);
                    contact.put("phone", phone);
                    contactsArray.put(contact);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            cursor.close();

            return syncContacts(contactsArray.toString());
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            Toast.makeText(MainActivity.this, result, Toast.LENGTH_LONG).show();
            if (result.contains("successfully")) {
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                db.delete(DatabaseHelper.TABLE_CONTACTS, null, null);
                loadContactsFromDatabase();
            }
        }

        private String syncContacts(String contactsJson) {
            String result = "";
            try {
                URL url = new URL("http://192.168.40.93/testing/offlinedata/sync_contacts.php");
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);

                Writer writer = new BufferedWriter(new OutputStreamWriter(httpURLConnection.getOutputStream(), "UTF-8"));
                writer.write(contactsJson);
                writer.close();

                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append(line);
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                result = stringBuilder.toString();
            } catch (MalformedURLException e) {
                e.printStackTrace();
                result = "MalformedURLException: " + e.getMessage();
            } catch (IOException e) {
                e.printStackTrace();
                result = "IOException: " + e.getMessage();
            }
            return result;
        }
    }
}
